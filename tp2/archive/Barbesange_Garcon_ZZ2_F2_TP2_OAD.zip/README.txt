###########################################################
#             TP2 - Outils d'Aide à la Décision           #
#                                                         #
#            BARBESANGE Benjamin - GARCON Benoît          #
###########################################################

Vous trouverez joint avec ce README, tous les fichiers 
utilisés lors de ce TP.

Les fichiers de code sont les suivants :
- main.cpp
- Bierwith.cpp   && Bierwith.h
- data.cpp       && data.h
- job.cpp        && job.h
- population.cpp && population .h

Un Makefile est inclut. Il suffit de taper la commande make 
pour compiler le code en un executable : tp2

Vous pouvez lancer le programme par la ligne de 
commande : ./tp2

Ou y ajouter des arguments : ./tp2 fichier
Cette commande permet de traiter le probleme de job-shop 
décrit dans le fichier d'entré

La commande : ./tp2 fichier 100 50
Va traiter le probleme de job-shop décrit dans le fichier en
utilisnt 100 réplications maximum dans l'algorithme 
génétique et en utilisant une population de 50 individus.

Le répertoire INSTANCES contient les fichiers utilisés pour 
tester le programme

Dans le répertoire doc se trouve le rapport associé à ce 
projet.


############################################## - ISIMA 2015
